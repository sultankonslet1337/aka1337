<?php
/**
 * The metabox functionality of the plugin
 * php version 5.2.4
 *
 * @package    SemrushSwa
 */

// Just an empty file to avoid directory listing.
